import random
print("Pick a number from: 32, 64, 128, 256, 512")
n = int(input())

m1 = []
m2 = []
mul = []

for i in range(n):
    row = []
    for j in range(n):
        row.append(random.randint(-2147483648, 2147483647))
    m1.append(row)

for i in range(n):
    row = []
    for j in range(n):
        row.append(random.randint(-2147483648, 2147483647))
    m2.append(row)

for i in range(n):
    row = []
    for j in range(n):
        value = 0
        for k in range(n):
            value += m1[i][k] * m2[k][j]

        row.append(value)
    mul.append(row)
    


