#include <iostream>
using namespace std;

int main()
{
    int n;
    cout<<"Pick a number from this set: 32, 64, 128, 256, 512";
    cin>>n;
    //cout<<"n is "<<n;
    double m1[n][n];
    double m2[n][n];
    double mul[n][n];
    
    for( int i=0; i<n; i++)
    {
      for( int j=0; j<n; j++)
      {
        m1[i][j]=rand();
        m2[i][j]=rand();
        mul[i][j]=0;
      }
    }
    
    for(int i = 0; i<n; i++)
     {
        for(int j = 0; j<n; j++)
        {
            for(int k = 0; k<n; k++)
            {
                mul[i][j] += (m1[i][k]) * (m2[k][j]);
            }
        }  
     }
     
     return 0;
}