#include <iostream>
#include<time.h>

using namespace std;

int fib(int n)
{
 if(n==0 or n==1)
 {
  return n;
 }
 
 else
 {
  return fib(n-1)+fib(n-2);
 }
}


int main()
{
    int time_taken;
    struct timespec start,end;
    
    timespec_get(&start, TIME_UTC);

    for( int i=0; i<100; i++)
    {
      cout<<fib(i)<<endl;
    }
    
    timespec_get(&end, TIME_UTC);
    time_taken = (end.tv_sec - start.tv_sec) * 1e9;
    time_taken = (time_taken + (end.tv_nsec - start.tv_nsec)) * 1e-9;
  
    cout<<"Time taken is:"<<time_taken;
    return 0;
}
//Author- Rahul Chembakasseril