#include <iostream>
#include <time.h>

using namespace std;

int main()
{
    int n=100;
    int first_fib=0;
    int second_fib=1;
    int next_fib;
    
    int time_taken;
    struct timespec start,end;
    
    timespec_get(&start, TIME_UTC);
    
    for( int i=0; i<n; i++)
    {
      if(i<=1)
      {
        next_fib=i;
      }
      else
      {
        next_fib=first_fib+second_fib;
        first_fib=second_fib;
        second_fib=next_fib;
      }
      
      cout<<next_fib<<endl;
    }
    
    timespec_get(&end, TIME_UTC);
    time_taken = (end.tv_sec - start.tv_sec) * 1e9;
    time_taken = (time_taken + (end.tv_nsec - start.tv_nsec)) * 1e-9;
  
    cout<<"Time taken is:"<<time_taken;

    return 0;
}

//Author-Rahul Chembakasseril