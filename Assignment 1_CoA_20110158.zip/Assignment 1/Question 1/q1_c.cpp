#include <iostream>
#include <time.h>

using namespace std;
int fib_numbers[101];

int fib(int n)
{
  if(n<=1)
  {
    return n;
  }
  if(fib_numbers[n]!=-2)
  {
    return fib_numbers[n];
  }
  fib_numbers[n]=fib(n-1)+fib(n-2);
  return fib_numbers[n];
}


int main()
{
    int m=100;
    int time_taken;
    struct timespec start,end;
    
    timespec_get(&start, TIME_UTC);
     
    for(int i=0; i<100; i++)
    {
      fib_numbers[i]=-2;
    }
    
    for(int j=0; j<m; j++)
    {
      cout<<fib(j)<<endl;  
    }
    
    timespec_get(&start, TIME_UTC);
    time_taken = (end.tv_sec - start.tv_sec) * 1e9;
    time_taken = (time_taken + (end.tv_nsec - start.tv_nsec)) * 1e-9;
  
    cout<<"Time taken is:"<<time_taken;
    return 0;
}

//Author-Rahul Chembakasseril